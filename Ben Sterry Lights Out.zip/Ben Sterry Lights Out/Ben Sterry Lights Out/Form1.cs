﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ben_Sterry_Lights_Out
{
    public partial class Form1 : Form
    {
        List<Color> Colors = new List<Color>()//This creates a list of colors(red and black). 
        { Color.Black,
          Color.Red
        };
        Random random = new Random();//This creates a Random class and gives a name. 
                                     //of random, to randomise the colors of the lights at the strt of the game.

        public Form1()
        {
            InitializeComponent();

            Button[,] lights = new Button[5, 5];//This creates an Array of Buttons of 5 x 5 using the Button Class.
            for (int row = 0; row < 5; row++)//This is a for loop which creates varibales  of "row" and "column" for each 
                for (int col = 0; col < 5; col++)//line of the button array.
                {
                    lights[row, col] = new Button();//This gives the buttons the variable name "lights".
                }

            for (int y = 0; y < 5; y++)//This for loop cyles through a range of 5 for the x and x lines .
            {                          //of the "grid" for the buttons.
                for (int x = 0; x < 5; x++)
                {
                    lights[x, y].Location = new System.Drawing.Point(5 + (50 * x), 5 + (50 * y));//This use the varibale name of buttons"lights" to set the position of the button.
                    lights[x, y].Name = "lights" + x.ToString() + y.ToString();//This gives a string name for the button to help with stack traces and naming  etc.
                    lights[x, y].Size = new System.Drawing.Size(50, 50);//Thiss creates the ssize of the button.
                    lights[x, y].TabIndex = x + (y * 5) + 1;//This enables the windows form system of "TabIndex" 
                    lights[x, y].BackColor = GetColors();//This call the GetColors() methos to color the button at the start of the game.
                    lights[x, y].Click += Button_Click;//This creates the event handler for the button which links toi the Button_Click event/method.
                    this.panel1.Controls.Add(lights[x, y]);//This renders the lights to the panel on the form.
                }
            }

            void Button_Click(object sender, EventArgs e)//This is the button click event assigned to the buttons on the form.
            {

                Button lightColor = (Button)sender;

                lightSwitch(lightColor);//This calls the lightswitch method below which switches the buttons between the two different colors.

                int lightX = ((lightColor.TabIndex - 1) % 5);//When clicked this detrmines the current loccation of the button using TabIndex, current position is 1, using -1 or + 1 with the % opertor will located the bottons left and right.
                int lightY = (int)((lightColor.TabIndex - 1) / 5);//Using the / operator with TabIndex will locate the buttons above and below.

                if (lightX > 0)
                {
                    lightSwitch(lights[(lightX - 1), lightY]);
                }

                if (lightX < (5 - 1))
                {
                    lightSwitch(lights[(lightX + 1), lightY]);
                }

                if (lightY > 0)
                {
                    lightSwitch(lights[lightX, (lightY - 1)]);
                }

                if (lightY < (5 - 1))
                {
                    lightSwitch(lights[lightX, (lightY + 1)]);
                }

            }
        }

        private void lightSwitch(Button lightColor)
        {
            if (lightColor.BackColor == Color.Red)//Simple If/else staemnt to toggle between the two colors for the button.
            {
                lightColor.BackColor = Color.Black;
            }
            else
            {
                lightColor.BackColor = Color.Red;
            }
        }

        public Color GetColors()
        {
            return Colors[random.Next(0, Colors.Count)];//This method retrieves the colors from the colors list and uses the Random Class
        }                                               //to randomise the colors of the buttons at the start of the game.




        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
