﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ben_Sterry_Lights_Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ben_Sterry_Lights_Out.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void Form1Test()
        {
            int[] ButtonArray = new int[] { 1, 2, 3, 4, 5 };

            CollectionAssert.AreEqual(new[] { 1, 2, 3, 4, 5 }, ButtonArray);//This is a Unit test for the array, the CollectionAssert will
        }                                                                   //will loop through the array and check each element for equality.

        [TestMethod()]
        public void GetColorsTest()
        {
            List<string> color = new List<string>();
            color.Add("Red");
            color.Add("Black");
            CollectionAssert.AllItemsAreUnique(color);//This unit test checks the array if each elemnt is unique.


            List<string> color2 = new List<string>();
            color2.Add("Red");
            color2.Add("Black");
            CollectionAssert.DoesNotContain(color2, "Yellow");//This unit test checks if the collection does or does not contain an item.
        }
    }
}